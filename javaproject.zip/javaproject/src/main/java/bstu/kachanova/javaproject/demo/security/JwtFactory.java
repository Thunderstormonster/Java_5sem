package bstu.kachanova.javaproject.demo.security;

public class JwtFactory {
    public void hello_there(){};
}
