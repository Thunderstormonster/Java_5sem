package bstu.kachanova.javaproject.demo.models;

public enum Role {
    ROLE_ADMIN,
    ROLE_USER
}