package bstu.kachanova.javaproject.demo.dto;

import java.util.Date;

public class DateRequest {
    private Date date;

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
}
