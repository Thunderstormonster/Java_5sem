package bstu.kachanova.javaproject.demo.service;

public class UserRoleService {
}
